package bsuir.vintsarevich.command;

public interface ICloseDBCommand {
    void closeDB();
}
