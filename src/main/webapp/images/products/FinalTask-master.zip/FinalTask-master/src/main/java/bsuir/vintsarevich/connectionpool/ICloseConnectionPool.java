package bsuir.vintsarevich.connectionpool;

public interface ICloseConnectionPool {
    void releasePool();
}
